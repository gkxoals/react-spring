package com.community.sample.user.DTO;

import lombok.Data;

@Data
public class UserLoginDTO {

    private String nickname;
    private String password;
}
